<?php
session_start();
require 'dbconfig.php';
//if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    //header("Location: login.php");
    //exit();
//}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <style>
        /* General Styles */
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(to right, #1e3c72, #2a5298);
            display: flex;
        }

        /* Sidebar */
        .sidebar {
            width: 260px;
            background: rgba(42, 63, 84, 0.9);
            height: 100vh;
            position: fixed;
            padding-top: 20px;
            color: white;
            box-shadow: 3px 0px 15px rgba(0, 0, 0, 0.3);
            backdrop-filter: blur(10px);
            transition: 0.3s ease-in-out;
        }

        .sidebar h2 {
            text-align: center;
            margin-bottom: 20px;
            font-size: 24px;
            font-weight: bold;
        }

        .sidebar a {
            display: block;
            color: white;
            padding: 14px 20px;
            text-decoration: none;
            transition: 0.3s;
            font-size: 18px;
            border-left: 4px solid transparent;
            position: relative;
        }

        .sidebar a:hover {
            background: rgba(255, 255, 255, 0.1);
            border-left: 4px solid #00bcd4;
        }

        .logout-btn {
            display: block;
            text-align: center;
            margin-top: 20px;
            padding: 12px;
            background: red;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin: 20px;
            font-weight: bold;
        }

        .logout-btn:hover {
            background: darkred;
        }

        /* Content Section */
        .content {
            margin-left: 280px;
            padding: 30px;
            width: calc(100% - 280px);
            color: white;
            text-align: center;
        }

        h2 {
            font-size: 32px;
        }

        p {
            font-size: 18px;
            color: #dcdcdc;
        }

        /* Card Styles */
        .card-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
        }

        .card {
            background: rgba(255, 255, 255, 0.15);
            width: 280px;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
            text-align: center;
            transition: transform 0.3s, box-shadow 0.3s;
            backdrop-filter: blur(10px);
        }

        .card:hover {
            transform: translateY(-8px);
            box-shadow: 0px 6px 15px rgba(255, 255, 255, 0.3);
        }

        .card h3 {
            margin: 0;
            color: white;
            font-size: 22px;
        }

        .card p {
            color: #dcdcdc;
            font-size: 14px;
            margin-top: 10px;
        }

        .card a {
            display: inline-block;
            text-decoration: none;
            padding: 10px 15px;
            background: #00bcd4;
            color: white;
            font-size: 16px;
            font-weight: bold;
            border-radius: 8px;
            transition: background 0.3s ease-in-out;
        }

        .card a:hover {
            background: #0097a7;
        }
    </style>
</head>
<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <h2>Student Panel</h2>
        <a href="student_registration.php">📝 Register</a>
        <a href="view_materials.php">📂 View Study Materials</a>
        <a href="view_announcements.php">📢 View Announcements</a>
        <a href="login.php" class="logout-btn">Logout</a>
    </div>

    <!-- Content Section -->
    <div class="content">
        <h2>Welcome, Student!</h2>
        <p>Access study materials and stay updated with announcements.</p>

        <div class="card-container">
            <div class="card">
                <h3>Register</h3>
                <p>Sign up for an account.</p>
                <a href="student_registration.php">Register</a>
            </div>

            <div class="card">
                <h3>Study Materials</h3>
                <p>Download learning resources.</p>
                <a href="view_materials.php">View</a>
            </div>

            <div class="card">
                <h3>Announcements</h3>
                <p>Stay updated with school news.</p>
                <a href="view_announcements.php">Check</a>
            </div>
        </div>
    </div>

</body>
</html>
