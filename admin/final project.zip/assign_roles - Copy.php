<?php
session_start();
require 'dbconfig.php';

// Debugging: Check database connection
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Uncomment this to restrict access to admin users
// if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
//     header("Location: login.php");
//     exit();
// }

// Handle Role Update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_role'])) {
    $user_id = $_POST['user_id'];
    $new_role = $_POST['role'];

    $sql = "UPDATE user SET Role='$new_role' WHERE UserID='$user_id'";
    if ($conn->query($sql) === TRUE) {
        header("Location: assign_roles.php");
        exit();
    } else {
        echo "Error updating role: " . $conn->error;
    }
}

// Fetch all users
$sql = "SELECT UserID, Name, Email, Role FROM user";
$result = $conn->query($sql);

// Debugging: Check for SQL errors
if (!$result) {
    die("Query Failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assign Roles</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: #f4f4f4;
            padding-top: 50px;
        }

        .container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            width: 90%;
            margin: auto;
        }

        h2 {
            color: #333;
        }

        .table-container {
            margin-top: 20px;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: green;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
             
        }

        th {
            background-color: #2a3f54;
            color: white;
        }

        .btn-edit {
            padding: 8px 12px;
            background: orange;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            text-decoration: none;
        }

        .btn-edit:hover {
            background: darkorange;
        }

        .back-btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            background: #28a745;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
            transition: background 0.3s ease-in-out;
        }

        .back-btn:hover {
            background: #218838;
        }

        @media screen and (max-width: 768px) {
            .container {
                width: 95%;
            }
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Assign or Change Roles</h2>

        <!-- Display User Accounts -->
        <div class="table-container">
            <table>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Current Role</th>
                    <th>Change Role</th>
                </tr>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                            <td>{$row['UserID']}</td>
                            <td>{$row['Name']}</td>
                            <td>{$row['Email']}</td>
                            <td>{$row['Role']}</td>
                            <td>
                                <button class='btn-edit' onclick='editRole({$row['UserID']}, \"{$row['Name']}\", \"{$row['Role']}\")'>Change Role</button>
                            </td>
                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No users available.</td></tr>";
                }
                ?>
            </table>
        </div>

        <a href="admin-panel.php" class="back-btn">Back to Dashboard</a>
    </div>

    <!-- Update Role Modal -->
    <div id="editModal" class="container" style="display: none;">
        <h3>Update User Role</h3>
        <form method="POST" action="assign_roles.php">
            <input type="hidden" name="user_id" id="edit_user_id">
            <p><strong>Name:</strong> <span id="edit_name"></span></p>
            <label for="role">Select New Role:</label>
            <select name="role" id="edit_role" required>
                <option value="Admin">Admin</option>
                <option value="Manager">Manager</option>
                <option value="Teacher">Teacher</option>
                <option value="School Director">School Director</option>
            </select>
            <br>
            <button type="submit" name="update_role">Update Role</button>
        </form>
    </div>

    <script>
        function editRole(id, name, role) {
            document.getElementById("edit_user_id").value = id;
            document.getElementById("edit_name").textContent = name;
            document.getElementById("edit_role").value = role;
            document.getElementById("editModal").style.display = "block";
        }
    </script>

</body>
</html>
