<?php
session_start();
require 'dbconfig.php'; // Include database connection

// Ensure only Manager can access
//if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Manager') {
//    header("Location: login.php");
//    exit();
//}

// Handle School Registration
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_school'])) {
    $name = trim($_POST['name']);
    $location = trim($_POST['location']);
    $school_type = trim($_POST['school_type']);

    // Update the SQL query to match the new table structure
    $sql = "INSERT INTO school (School_name, Location, School_type) 
            VALUES ('$name', '$location', '$school_type')";
    if ($conn->query($sql) === TRUE) {
        header("Location: manage_schools.php");
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}

// Handle School Update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_school'])) {
    $id = $_POST['id'];
    $name = trim($_POST['name']);
    $location = trim($_POST['location']);
    $school_type = trim($_POST['school_type']);
    $status = $_POST['status'];

    // Update the SQL query to match the new table structure
    $sql = "UPDATE school SET School_name='$name', Location='$location', School_type='$school_type' WHERE School_id='$id'";
    if ($conn->query($sql) === TRUE) {
        header("Location: manage_schools.php");
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}

// Handle School Deletion
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    // Update the SQL query to match the new table structure
    $sql = "DELETE FROM school WHERE School_id='$id'";
    if ($conn->query($sql) === TRUE) {
        header("Location: manage_schools.php");
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}

// Handle Search and Filtering
$search = isset($_GET['search']) ? $_GET['search'] : '';
$filter_status = isset($_GET['status']) ? $_GET['status'] : '';

// SQL Query with Search and Filter
$sql = "SELECT * FROM school WHERE 1";

if (!empty($search)) {
    $sql .= " AND (School_name LIKE '%$search%' OR Location LIKE '%$search%')";
}

if (!empty($filter_status)) {
    $sql .= " AND status = '$filter_status'";
}

$sql .= " ORDER BY School_id DESC";

$result = $conn->query($sql);

// Check if query executed successfully
if (!$result) {
    die("Error: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Schools</title>

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">

    <!-- Header -->
    <header class="bg-teal-700 text-white py-4">
        <div class="container mx-auto flex justify-between items-center px-6">
            <h1 class="text-xl font-bold">Manage Schools</h1>
            <a href="manager_panel.php" class="bg-gray-300 text-black px-4 py-2 rounded">Back to Dashboard</a>
        </div>
    </header>

    <!-- School Registration Form -->
    <section class="container mx-auto mt-6 bg-white p-6 rounded-lg shadow-lg">
        <h2 class="text-2xl font-semibold text-gray-700 mb-4">Register a New School</h2>
        <form method="POST" action="manage_schools.php" class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input type="text" name="name" placeholder="School Name" required class="p-2 border rounded">
            <input type="text" name="location" placeholder="Location" required class="p-2 border rounded">
            <select name="school_type" required class="p-2 border rounded">
                <option value="">Select School Type</option>
                <option value="Pre-primary">Pre-primary</option>
                <option value="Primary">Primary</option>
                <option value="Secondary">Secondary</option>
            </select>
            <button type="submit" name="add_school" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-700">
                Register School
            </button>
        </form>
    </section>

    <!-- Search & Filter Form -->
    <section class="container mx-auto mt-6 bg-white p-6 rounded-lg shadow-lg">
        <h2 class="text-2xl font-semibold text-gray-700 mb-4">Search & Filter Schools</h2>
        <form method="GET" action="manage_schools.php" class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <input type="text" name="search" placeholder="Search by Name or Location" value="<?php echo $search; ?>" class="p-2 border rounded">
            <select name="status" class="p-2 border rounded">
                <option value="">All Status</option>
                <option value="Active" <?php if ($filter_status == 'Active') echo 'selected'; ?>>Active</option>
                <option value="Inactive" <?php if ($filter_status == 'Inactive') echo 'selected'; ?>>Inactive</option>
            </select>
            <button type="submit" class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-700">
                Search & Filter
            </button>
        </form>
    </section>

    <!-- School List -->
    <section class="container mx-auto mt-6 bg-white p-6 rounded-lg shadow-lg">
        <h2 class="text-2xl font-semibold text-gray-700 mb-4">Registered Schools</h2>
        <table class="w-full border-collapse border border-gray-300">
            <thead class="bg-gray-800 text-white">
                <tr>
                    <th class="p-3 border">School Name</th>
                    <th class="p-3 border">Location</th>
                    <th class="p-3 border">School Type</th>
                    <th class="p-3 border">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()) { ?>
                    <tr class="text-center bg-gray-100">
                        <td class="p-3 border"><?php echo $row['School_name']; ?></td>
                        <td class="p-3 border"><?php echo $row['Location']; ?></td>
                        <td class="p-3 border"><?php echo $row['School_type']; ?></td>
                        <td class="p-3 border">
                            <a href="manage_schools.php?delete=<?php echo $row['School_id']; ?>" class="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-700">Delete</a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </section>

</body>
</html>
